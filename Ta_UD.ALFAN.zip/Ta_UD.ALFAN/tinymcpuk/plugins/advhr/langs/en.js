// UK lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Horizontale rule',
insert_advhr_width : 'Width',
insert_advhr_size : 'Height',
insert_advhr_noshade : 'No shadow'
});
